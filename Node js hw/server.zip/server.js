const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const users = require("./users");
const path = require("path");
const router = express.Router();

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "html1.html"));
});

router
  .route("/users")
  .get((req, res) => res.json(users))
  .post((req, res) => res.json(users));

router
  .route("/:id")
  .get((req, res) => {
    const searchedID = req.params.id;
    const userSearched = users.id.searchedID;
    res.json(userSearched);
  })
  .put((req, res) => {
    const searchedID = req.params.id;
    const userSearched = users.id.searchedID;
    res.json(userSearched);
  })
  .delete((req, res) => {
    const searchedID = req.params.id;
    const userSearched = users.id.searchedID;
    res.json(userSearched);
  });

app.listen(port, () => console.log(`Server started on port ${port}`));
