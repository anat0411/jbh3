import React from "react";
import EmployeesBase from "./components/EmployeesBase";

function App() {
  return (
    <div className="App">
      <EmployeesBase />
    </div>
  );
}
export default App;
