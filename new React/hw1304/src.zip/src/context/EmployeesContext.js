import React from "react";

const EmployeesContext = React.createContext();

export default EmployeesContext;
